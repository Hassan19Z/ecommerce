import { model, Schema, Types } from "mongoose"

const reviewSchema= new Schema({
    comment: String,
    user: {
        type: Types.ObjectId,
        ref: 'User'
    },
    rate:{
        type: Number,
        min:0,
        max:5,
        required:true
    },
    createdBy:{
        type: Types.ObjectId,
        ref: 'User'
    },
    user: {
        type: Types.ObjectId,
        ref: 'Product'
    },
},{timestamps: true , versionKey: false})

export const Review = model('Review', reviewSchema)