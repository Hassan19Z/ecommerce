export const gender ={
    MALE: 'male',
    FEMALE: 'female'
}
Object.freeze(gender)
export const systemRole={
    USER: "user",
    ADMIN: "admin"
}
Object.freeze(systemRoles)
export const references={
    PRODUCT: "Product",
    COMMENT: "Comment"
}
Object.freeze(references)

export const status= {
    OFFLINE: "offline",
    ONLINE: "online"
}
Object.freeze(status)


export const workingTime= {
    PARTTIME: "part-time",
    FULLTIME: "full-time"
}
Object.freeze(status)