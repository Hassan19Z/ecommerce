import express from 'express';
import { connectDB } from './databases/models/dbconnection.js';
import { globalErrorHandling } from './src/middleWare/asyncHandler.js';
import multer from 'multer';

const app = express()
const port = 3000
app.use('/uploads', express.static('uploads'))
bootstrap(app)
app.use(express.json())
app.use(globalErrorHandling)
app.listen(port, () => console.log(`Example app listening on port ${port}!`))
