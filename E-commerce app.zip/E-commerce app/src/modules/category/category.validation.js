import Joi, { required } from "joi";

//! update user 
export const categoryVal = Joi.object({
    name:Joi.string().min(1).max(100).required(),
}).required()