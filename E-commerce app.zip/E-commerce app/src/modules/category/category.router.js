import { Router } from "express";
import { asyncHandler } from "../../middleWare/asyncHandler.js";
import { addSubCategory, allSubCategories, deleteSubCategory, getSubCategory, updateSubCategory } from "./category.controller.js";
import { uploadSingleFile } from "../../fileUpload/fileUpload.js";
import { validate } from "uuid";
import { categoryVal } from "./category.validation.js";



const categoryRouter = Router()

categoryRouter
.route('/')
.post(uploadSingleFile('image' , 'categories'),validate(categoryVal), asyncHandler(addSubCategory))
categoryRouter
.route('/')
.get(asyncHandler(allSubCategories))
categoryRouter
.route('/:id')
.get( asyncHandler(getSubCategory))
categoryRouter
.route('/:id')
.put(uploadSingleFile('image' , 'categories'), asyncHandler(updateSubCategory))
categoryRouter
.route('/:id')
.delete(asyncHandler(deleteSubCategory))

export default categoryRouter