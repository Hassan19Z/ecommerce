import slugify from "slugify";
import { Category } from "../../../databases/models/category.model.js";
import { AppError } from "../../../utils/appError.js";

const addCategory =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    req.body.image = req.file.filename
    let category = new Category(req.body)
    Category.name
    await category.save()

    res.json({message:'success', category})
}

const allCategories =async(req, res, next) => {
    let categories = Category.find()
    res.json({message:'success', categories})
}

const getCategory =async(req, res, next) => {
    let category = Category.findById(req.param.id)
    category || next(new AppError('Category not found'))
    !category || res.json({message:'success', category})
}

const updateCategory =async(req, res, next) => {
    if (req.file) req.body.slug = slugify(req.body.name)
    if (req.file) req.body.image= req.file.filename
    if (req.file) {
        // Remove the old image
        fs.unlinkSync(`${publicUploads}${Category.image}`);
        Category.image = req.file.filename;
    }
    let category = Category.findByIdAndDelete(req.param.id,req.body,{new: true})
    category || next(new AppError('Category not found'))
    !category || res.json({message:'success', category})
}
const deleteCategory =async(req, res, next) => {
    let category = Category.findByIdAndDelete(req.param.id)
        category || next(new AppError('Category not found'))
        !category || res.json({message:'success', category})
}


export {
    addCategory,
    allCategories,
    getCategory,
    updateCategory,
    deleteCategory
}