import slugify from "slugify";
import { AppError } from "../../../utils/appError.js";
import { SubCategory } from "../../../databases/models/subCategory.model.js";

const addSubCategory =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    let subcategory = new SubCategory(req.body)
    await subcategory.save()

    res.json({message:'success', subcategory})
}

const allSubCategory =async(req, res, next) => {
    let subcategory = SubCategory.find()
    res.json({message:'success', subcategory})
}

const getSubCategory =async(req, res, next) => {
    let subcategory = SubCategory.findById(req.param.id)
    subcategory || next(new AppError('subcategory not found'))
    !subcategory || res.json({message:'success', subcategory})
}

const updateSubCategory =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    let subcategory = SubCategory.findByIdAndDelete(req.param.id,req.body,{new: true})
    subcategory || next(new AppError('subcategory not found'))
    !subcategory || res.json({message:'success', subcategory})
}
const deleteSubCategory =async(req, res, next) => {
    let subcategory = SubCategory.findByIdAndDelete(req.param.id)
        subcategory || next(new AppError('subcategory not found'))
        !subcategory || res.json({message:'success', subcategory})
}


export {
    addSubCategory,
    allSubCategory,
    getSubCategory,
    updateSubCategory,
    deleteSubCategory
}