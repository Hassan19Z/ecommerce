import { Router } from "express";
import { asyncHandler } from "../../middleWare/asyncHandler.js";
import { addSubCategory, allSubCategory, deleteSubCategory, getSubCategory, updateSubCategory } from "./subCategory.controller.js";
import { validate } from "uuid";
import { subCategoryVal } from "./subcategory.validation.js";



const SubcategoryRouter = Router()

SubcategoryRouter
.route('/')
.post('/', validate(subCategoryVal), asyncHandler(addSubCategory))
SubcategoryRouter
.route('/')
.get('/', asyncHandler(allSubCategory))
SubcategoryRouter
.route('/')
.get('/', asyncHandler(getSubCategory))
SubcategoryRouter
.route('/')
.put('/', asyncHandler(updateSubCategory))
SubcategoryRouter
.route('/')
.delete('/', asyncHandler(deleteSubCategory))

export default SubcategoryRouter