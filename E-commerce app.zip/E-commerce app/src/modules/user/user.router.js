import { Router } from "express";
import { asyncHandler } from "../../middleWare/asyncHandler.js";
import { auth } from "../../middleWare/auth.middle.js";
import { addUser, allUsers, deleteProfile, getMyProfile, updateProfile } from "./user.controller.js";
import { validation } from "../../middleWare/validation.js";
import { updateProfileVal } from "./user.validation.js";

const userRouter = Router()

categoryRouter
.route('/')
.post('/', asyncHandler(addUser))
categoryRouter
.route('/')
.get('/', asyncHandler(allUsers))
categoryRouter
.route('/')
.get('/', asyncHandler(getMyProfile))
categoryRouter
.route('/')
.put('/', asyncHandler(updateProfile))
categoryRouter
.route('/')
.delete('/', asyncHandler(updateProfile))
export {userRouter}