import { Router } from "express";
import { asyncHandler } from "../../middleWare/asyncHandler.js";
import { addBrand, allBrand, deleteBrand, getBrand, updateBrand } from "./brand.controller.js";
import { uploadSingleFile } from "../../fileUpload/fileUpload.js";
import { validate } from "uuid";
import { brandVal } from "./brand.validation.js";



const brandRouter = Router()

brandRouter
.route('/')
.post('/',uploadSingleFile('logo' , 'brands'),validate(brandVal), asyncHandler(addBrand))
brandRouter
.route('/')
.get('/', asyncHandler(allBrand))
brandRouter
.route('/')
.get('/', asyncHandler(getBrand))
brandRouter
.route('/')
.put('/',uploadSingleFile('logo' , 'brands'), asyncHandler(updateBrand))
brandRouter
.route('/')
.delete('/', asyncHandler(deleteBrand))

export default brandRouter