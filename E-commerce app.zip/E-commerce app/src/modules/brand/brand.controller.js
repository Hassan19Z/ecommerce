import slugify from "slugify";
import { AppError } from "../../../utils/appError.js";
import { Brand } from "../../../databases/models/brands.model.js";

const addBrand =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    req.body.logo = req.file.filename
    let brand = new Brand(req.body)
    await brand.save()

    res.json({message:'success', brand})
}

const allBrand =async(req, res, next) => {
    let brands = Brand.find()
    res.json({message:'success', brands})
}

const getBrand =async(req, res, next) => {
    let brand = Brand.findById(req.param.id)
    brand || next(new AppError('brand not found'))
    !brand || res.json({message:'success', brand})
}

const updateBrand =async(req, res, next) => {
    if (req.file)req.body.slug = slugify(req.body.name)
    if (req.file) req.body.logo= req.file.filename
    if (req.file) {
        // Remove the old logo
        fs.unlinkSync(`${publicUploads}${Brand.logo}`);
        Brand.logo = req.file.filename;
    }
    let brand = Brand.findByIdAndDelete(req.param.id,req.body,{new: true})
    brand || next(new AppError('brand not found'))
    !brand || res.json({message:'success', brand})
}
const deleteBrand =async(req, res, next) => {
    let brand = Brand.findByIdAndDelete(req.param.id)
        brand || next(new AppError('brand not found'))
        !brand || res.json({message:'success', brand})
}


export {
    addBrand,
    allBrand,
    getBrand,
    updateBrand,
    deleteBrand
}