import Joi, { required } from "joi";

//! update user 
export const productVal = Joi.object({
    title:Joi.string().min(1).max(100).required(),
}).required()