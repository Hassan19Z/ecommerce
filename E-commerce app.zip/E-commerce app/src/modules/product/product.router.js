import { Router } from "express";
import { asyncHandler } from "../../middleWare/asyncHandler.js";
import { addProduct, allProduct, deleteProduct, getProduct, updateProduct } from "./product.controller.js";
import { uploadMixOfFiles } from "../../fileUpload/fileUpload.js";
import { validate } from "uuid";
import { productVal } from "./product.validation.js";



const productRouter = Router()

productRouter
.route('/')
.post(uploadMixOfFiles([{name: 'imageCover', maxCount: 1},{name: 'images', maxCount: 10}], 'products'),validate(productVal), asyncHandler(addProduct))
productRouter
.route('/')
.get(asyncHandler(allProduct))
productRouter
.route('/')
.get(asyncHandler(getProduct))
productRouter
.route('/')
.put(uploadMixOfFiles([{name: 'imageCover', maxCount: 1},{name: 'images', maxCount: 10}], 'products'), asyncHandler(updateProduct))
productRouter
.route('/')
.delete(asyncHandler(deleteProduct))

export default productRouter