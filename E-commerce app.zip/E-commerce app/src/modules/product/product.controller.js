import slugify from "slugify";
import { AppError } from "../../../utils/appError.js";
import { Product } from "../../../databases/models/product.model.js";

const addProduct =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    req.body.imageCover= req.files.imageCover[0].filename
    req.body.images = req.files.imges.map(img=>img.filename)
    let product = new Product(req.body)
    await product.save()

    res.json({message:'success', product})
}

const allProduct =async(req, res, next) => {
    let products = Product.find()
    res.json({message:'success', products})
}

const getProduct =async(req, res, next) => {
    let product = Product.findById(req.param.id)
    product || next(new AppError('product not found'))
    !product || res.json({message:'success', product})
}

const updateProduct =async(req, res, next) => {
    req.body.slug = slugify(req.body.name)
    let product = Product.findByIdAndDelete(req.param.id,req.body,{new: true})
    product || next(new AppError('product not found'))
    !product || res.json({message:'success', product})
}
const deleteProduct =async(req, res, next) => {
    let product = Product.findByIdAndDelete(req.param.id)
        product || next(new AppError('product not found'))
        !product || res.json({message:'success', product})
}


export {
    addProduct,
    allProduct,
    getProduct,
    updateProduct,
    deleteProduct
}